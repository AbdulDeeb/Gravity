#libraries 
library(nloptr)
library(cowplot)
library(ggplot2)
library(boot)
library(ggpubr)
library(sciplot) # se function
library(gtools)
library(data.table)
library(ez)
library(lsr)

rm(list=ls())
options(scipen = 100)
#empty dataframes
allData=NULL
subjectLvlAvg= NULL
varset = NULL
#velocities
vEarth <- c(3.14, 4.08, 5.2, 6.8, 8.14, 10.58) 
vJupiter <- c(5.2, 6.8, 8.35, 10.86, 13.6, 17.68)
vMercury <- c(2, 2.6, 3.2, 4.2, 5.2, 6.8) 
GlobalLvlAvg = NULL
GlobalLvlVar = NULL
GlobalLvlAvgtemp = NULL
dir = paste("~/Documents/Gravity/Sensory exp 22/")
setwd(dir)
filelist= list.files(pattern = ".txt") #extracts experimental files

for (name in filelist) { 
  print(paste(name))
  dir = paste("~/Documents/Gravity/Sensory exp 22/", name,sep='')
  regexpress=paste("trial")
  trialFiles = mixedsort(list.files()[grep(regexpress, list.files())])
  sbData=NULL
  
  tempy <- read.table(name, header = TRUE, sep = "", dec = ".")
  tempy$probePos = tempy$probePos + 600
  allData = rbind(allData, tempy)
  rm(trialFiles)
  #rm(tempy)
  keeps <- c("subjName","trialN","ballPos_z","Occlusion","probePos")
  
  subjectLvlsimple = NULL
  subjectLvlsimple <- tempy[keeps]
  subjectLvlsimpleTempy <- subjectLvlsimple
  subjectLvlAvg = with(subjectLvlsimpleTempy,aggregate(probePos,
                                                       by=list(subjName = subjName,
                                                               ballPos_z=ballPos_z,
                                                               Occlusion = Occlusion), mean))
  names(subjectLvlAvg)[4]="probePos"
  
  subjectLvlVar = with(subjectLvlsimpleTempy,aggregate(probePos,
                                                       by=list(subjName = subjName,
                                                               ballPos_z=ballPos_z,
                                                               Occlusion = Occlusion), var))
  names(subjectLvlVar)[4]="Variance"

  GlobalLvlAvgtemp <- rbind(GlobalLvlAvgtemp, subjectLvlAvg)
  GlobalLvlVar <- rbind(GlobalLvlVar, subjectLvlVar)
  
  GlobalLvlAvg <-  with(GlobalLvlAvgtemp,aggregate(probePos,
                                       by=list( ballPos_z=ballPos_z,
                                                Occlusion= Occlusion), mean))
  names(GlobalLvlAvg)[3]="probePos"
  

}

GlobalLvlAvg$se = as.vector(with(allData,as.table(by(probePos,list(ballPos_z,Occlusion),se,na.rm=T))))
GlobalLvlAvg$sd = as.vector(with(allData,as.table(by(probePos,list(ballPos_z,Occlusion),sd,na.rm=T))))/sqrt(13)


varset <- with(allData,aggregate(probePos,
                                            by=list( ballPos_z=ballPos_z, 
                                                     Occlusion= Occlusion
                                                     ), var))
names(varset)[3]="Variance"

GlobalLvlVar$SD <- sqrt(GlobalLvlVar$Variance)
  

ggplot(allData, aes(x=ballPos_z,y=probePos, color = as.factor(Occlusion), 
                          group = as.factor(Occlusion) )) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=.5) +
  xlab("Displayed Position in Z (mm) " ) + ylab("Response in Z (mm)" )+  coord_equal()+
  theme_classic() 

ggplot(GlobalLvlAvg, aes(x=ballPos_z,y=probePos, color = as.factor(Occlusion), group = as.factor(Occlusion) )) +
  geom_point() + geom_line()+
  geom_errorbar(aes(ymin=probePos-sd, ymax=probePos+sd), width=0,size = 1, position=position_dodge(.9)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  coord_equal()+
  theme_minimal() 

#variance

ggplot(GlobalLvlVar, aes(x=ballPos_z,y = SD, color = as.factor(Occlusion), group = as.factor(Occlusion)))+
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=.5) +
  coord_fixed(ratio = 4)+
  theme_minimal() 
#Basic Stats

allData$ballPos_z <- as.factor(allData$ballPos_z)
allData$Occlusion <- as.factor(allData$Occlusion)
aov = ezANOVA(data = allData, dv = probePos, wid = subjName, within = .(ballPos_z,Occlusion))


GlobalLvlVar$ballPos_z <- as.factor(GlobalLvlVar$ballPos_z)
GlobalLvlVar$Occlusion <- as.factor(GlobalLvlVar$Occlusion)
aov2 = ezANOVA(data = GlobalLvlVar, dv = Variance, wid = subjName, within = .(ballPos_z,Occlusion))





#########find the ws in IC model, using GlobalLvlAvgtemp#######



Bm = function(guess,ballPos_z, data){
  # Parameters
  W_s = guess[1] # we are fitting the reliability of the prediction
  Z_s = ballPos_z
  
  # Model Equation
  Z_hat = sqrt((W_s*Z_s )^2)
  
  simulation_error = sqrt(mean((Z_hat-data)^2,na.rm=T)) #RMSE
  
  return (simulation_error)
}
# Setup for the optimizer

vec = NULL
guess = c(runif(1, 1, 300)) # initial guess for the fit parameter
LB =  c(0.0)
UB =  c(1000.0)
opt_print=0
options = list('algorithm'='NLOPT_LN_COBYLA',#'NLOPT_LN_BOBYQA',#'NLOPT_LN_NELDERMEAD',#'NLOPT_LN_SBPLX',
               'print_level'=opt_print,
               'maxtime'=240) # better not take this long

# Do the Optimization
outdata=NULL
fitParams_bySubj = NULL
for (sb in unique(GlobalLvlAvgtemp$subjName)){
  tempfit = subset(GlobalLvlAvgtemp, subjName==sb)
  soln = nloptr(x0 = guess,
                eval_f = Bm,
                lb = LB,
                ub = UB,
                opts=options,
                ballPos_z = as.numeric(as.character(tempfit$ballPos_z)),
                data = tempfit$probePos)
  
  tempfit$SensoryPrecision=soln$solution
  
  fitParams_bySubj=c(fitParams_bySubj,soln$solution)
  
  outdata = rbind(outdata, tempfit) 
}
outdata$ballPos_z = as.numeric(as.character(outdata$ballPos_z))

outdata$model_fit = sqrt((outdata$ballPos_z*outdata$SensoryPrecision)^2)

  ggplot(data=outdata,aes(x=as.numeric(as.character(ballPos_z)),y=probePos)) +
    geom_abline(intercept=0,slope=1,lty='longdash') +
    stat_summary(fun.data='mean_se',aes(y=model_fit),geom='point',alpha=.3) +
    stat_summary(fun.data='mean_se',aes(y=model_fit),geom='line', linetype = "dashed") + 
    stat_summary(fun.data='mean_se',geom='point',alpha=.9) +
    stat_summary(fun.data='mean_se',geom='line',alpha=.9) +
    coord_equal()+
    xlab("Postion in Z") + 
    ylab(" Judgment in Z")+
    ggtitle("IC model, EXP 3")+
    theme_minimal() 

#extract mean value of Sensory Precision 
w_s <- mean(outdata$SensoryPrecision)
kz = 1.825758

#General modelling###### 

dir <- paste("~/Documents/Gravity/MainExp2/") 
setwd(dir)
load('EXP1data')
EXP1data$ballPos_z[EXP1data$ballPos_z < 35] <- 34.25
EXP1data$ballPos_z[EXP1data$ballPos_z > 35 & EXP1data$ballPos_z < 50  ] <- 44.50
EXP1data$ballPos_z[EXP1data$ballPos_z > 50 & EXP1data$ballPos_z < 60  ] <- 55.00
EXP1data$ballPos_z[EXP1data$ballPos_z > 70 & EXP1data$ballPos_z < 73  ] <- 72.00
EXP1data$ballPos_z[EXP1data$ballPos_z > 73 & EXP1data$ballPos_z < 90  ] <- 89.00
EXP1data$ballPos_z[EXP1data$ballPos_z > 90 & EXP1data$ballPos_z < 120  ] <- 116.50


#set up data file, by averaging over trials within subject, by important conditions 
ModelData <- with(EXP1data,aggregate(probePos,
                                     by=list(subjName = subjName,
                                             Gravity = Gravity, 
                                             speed = speed, 
                                             ballPos_z=ballPos_z
                                     ), mean))

names(ModelData)[5]="probePos"
ModelData$precisions <- 0
ModelData$precisions[ModelData$ballPos_z == 34.25] <- mean(1/varset$Variance[varset$ballPos_z == 34.25])
ModelData$precisions[ModelData$ballPos_z == 44.50] <- mean(1/varset$Variance[varset$ballPos_z == 44.50])
ModelData$precisions[ModelData$ballPos_z == 55.00] <- mean(1/varset$Variance[varset$ballPos_z == 55.00])
ModelData$precisions[ModelData$ballPos_z == 72.00] <- mean(1/varset$Variance[varset$ballPos_z == 72.00])
ModelData$precisions[ModelData$ballPos_z == 89.00] <- mean(1/varset$Variance[varset$ballPos_z == 89.00])
ModelData$precisions[ModelData$ballPos_z == 116.50] <- mean(1/varset$Variance[varset$ballPos_z == 116.50])
kz <- 1.825758
h <-  67.83 #mm
ModelData$E_pred  <- (ModelData$speed/11.76) *sqrt((2*h)/(9.81* (10^-3))) 




######MLE model##### 
Bm = function(guess,ballPos_z,E_pred,reliabilities, data){
  # Parameters
  R_n = guess[1] # we are fitting the reliability of the prediction
  R_i = reliabilities
  alpha_i = ballPos_z
  alpha_n = E_pred
  
  # Model Equation
  alpha_hat = (R_i/(R_i + R_n ))*alpha_i + (1- (R_i/(R_i + R_n )))*alpha_n
  
  simulation_error = sqrt(mean((alpha_hat-data)^2,na.rm=T)) #RMSE
  
  return (simulation_error)
}
# Setup for the optimizer

vec = NULL
guess = c(runif(1, 1, 300)) # initial guess for the fit parameter
LB =  c(0.0)
UB =  c(1000.0)
opt_print=0
options = list('algorithm'='NLOPT_LN_COBYLA',#'NLOPT_LN_BOBYQA',#'NLOPT_LN_NELDERMEAD',#'NLOPT_LN_SBPLX',
               'print_level'=opt_print,
               'maxtime'=240) # better not take this long

# Do the Optimization
outdata=NULL
fitParams_bySubj = NULL
for (sb in unique(ModelData$subjName)){
  tempfit = subset(ModelData, subjName==sb)
  soln = nloptr(x0 = guess,
                eval_f = Bm,
                lb = LB,
                ub = UB,
                opts=options,
                ballPos_z = as.numeric(as.character(tempfit$ballPos_z)),
                E_pred = tempfit$E_pred,
                reliabilities = tempfit$precision,
                data = tempfit$probePos)
  
  tempfit$newtonianPrecision=soln$solution
  
  fitParams_bySubj=c(fitParams_bySubj,soln$solution)
  
  outdata = rbind(outdata, tempfit) 
}
outdata$ballPos_z = as.numeric(as.character(outdata$ballPos_z))
outdata$currentInfoWeight = (outdata$precision/(outdata$precision + outdata$newtonianPrecision))



outdata$model_fit = outdata$currentInfoWeight*outdata$ballPos_z + (1-outdata$currentInfoWeight)*outdata$E_pred

outdata2 = as.data.frame.table(with(outdata,as.table(by(probePos,list(subjName,ballPos_z,Gravity),mean,na.rm=T))))
names(outdata2) = c('subject','ballPos_z','Gravity','probePos')
outdata2$model_fit = as.vector(with(outdata,as.table(by(model_fit,list(subjName,ballPos_z,Gravity),mean,na.rm=T))))





MLE <- ggplot(data=outdata2,aes(x=as.numeric(as.character(ballPos_z)),y=model_fit, color = Gravity)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',aes(y= probePos ,fill=Gravity),geom='point',alpha=.75) +
  stat_summary(fun.data='mean_se',aes(y=probePos),geom='line', linetype = "dashed", alpha=.75) + 
  #stat_summary(fun.data='mean_se',aes(y=probePos),geom='point',alpha=.9, aes(fill=Gravity)) +
  stat_summary(fun.data='mean_se',geom='line',alpha=.9, size = 1) +
  coord_equal()+
  xlab("Postion in Z") + 
  ylab(" Judgment in Z")+
  ggtitle("MLE model, true Vz")+
  theme_minimal() 


##############SSM#######

Bm = function(guess,ballPos_z,Gravity, w_s, data){
  # Parameters
  W_e = guess[1] # we are fitting the reliability of the prediction
  w_s <-1.03388
  Z_s = ballPos_z
  Rg = Gravity/9.81
  
  # Model Equation
  #alpha_hat = sqrt(R_n*((kz^2 * Rg)-1) +1)*alpha_i
  #alpha_hat = sqrt(R_n*(Rg-1) +1)*alpha_i
  #alpha_hat = sqrt(R_n*(Rg) +1)*alpha_i
  Z_hat = sqrt(W_e*Rg +w_s)*Z_s
  simulation_error = sqrt(mean((Z_hat-data)^2,na.rm=T)) #RMSE
  return (simulation_error)
}
# Setup for the optimizer

vec = NULL
guess = c(runif(1, 1, 300)) # initial guess for the fit parameter
LB =  c(0.0)
UB =  c(1000.0)
opt_print=0
options = list('algorithm'='NLOPT_LN_COBYLA',#'NLOPT_LN_BOBYQA',#'NLOPT_LN_NELDERMEAD',#'NLOPT_LN_SBPLX',
               'print_level'=opt_print,
               'maxtime'=240) # better not take this long

# Do the Optimization
outdata_ic=NULL
fitParams_bySubj = NULL
for (sb in unique(ModelData$subjName)){
  tempfit = subset(ModelData, subjName==sb)
  soln = nloptr(x0 = guess,
                eval_f = Bm,
                lb = LB,
                ub = UB,
                opts=options,
                ballPos_z = as.numeric(as.character(tempfit$ballPos_z)),
                Gravity = tempfit$Gravity,
                w_s = w_s,
                data = tempfit$probePos)
  
  tempfit$newtonianPrecision=soln$solution
  
  fitParams_bySubj=c(fitParams_bySubj,soln$solution)
  
  outdata_ic = rbind(outdata_ic, tempfit) 
}
#outdata_ic$ballPos_z = as.numeric(as.character(outdata_ic$ballPos_z))

outdata_ic$model_fit =sqrt(outdata_ic$newtonianPrecision* (outdata_ic$Gravity/9.81) +w_s)*outdata_ic$ballPos_z
outdata_ic$Gravity <- as.factor(outdata_ic$Gravity)

ic <- ggplot(data=outdata_ic,aes(x=as.numeric(as.character(ballPos_z)),y=probePos, color = Gravity, group = Gravity)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
 stat_summary(fun.data='mean_se',aes(y=model_fit,fill=Gravity),geom='point',alpha=.3) +
  stat_summary(fun.data='mean_se',aes(y=model_fit),geom='line', linetype = "dashed") + 
  stat_summary(fun.data='mean_se',geom='point',alpha=.9, aes(fill=Gravity)) +
  stat_summary(fun.data='mean_se',geom='line',alpha=.9) +
  coord_equal()+
  xlab("Postion in Z") + 
  ylab(" Judgment in Z")+
  ggtitle("IC model, 9/20")+
  theme_minimal() 
ggarrange(ic, MLE)


model1 <- lm(model_fit ~probePos,data =  outdata_ic)

summary(model1)
model2 <- lm(model_fit ~probePos,data =  outdata2)

summary(model2)

outdata3 = as.data.frame.table(with(outdata,as.table(by(probePos,list(subjName,ballPos_z,Gravity),mean,na.rm=T))))
names(outdata3) = c('subject','ballPos_z','Gravity','probePos')
outdata3$model_fit = as.vector(with(outdata,as.table(by(model_fit,list(subjName,ballPos_z,Gravity),mean,na.rm=T))))
#outdata3$Gravity <- as.numeric(as.character(outdata3$Gravity))
#outdata3$ballPos_z <- as.numeric(as.character(outdata3$ballPos_z))

ssm <- ggplot(data=outdata3,aes(x=as.numeric(as.character(ballPos_z)),y=probePos, color = Gravity)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',aes(y=model_fit,fill=Gravity),geom='point',alpha=.3) +
  stat_summary(fun.data='mean_se',aes(y=model_fit),geom='line', linetype = "dashed") + 
  stat_summary(fun.data='mean_se',geom='point',alpha=.9, aes(fill=Gravity)) +
  stat_summary(fun.data='mean_se',geom='line',alpha=.9) +
  coord_equal()+
  xlab("Postion in Z") + 
  ylab(" Judgment in Z")+
  ggtitle("IC model: sqrt(Fit value of Newtonian Weight*
          ((kz^2 * Gravity/9.81)-1) +1)
          *ballPos_z")+
  theme_minimal() 

ic <- ggplot(data=outdata_ic,aes(x=as.numeric(as.character(ballPos_z)),y=model_fit, color = Gravity)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',aes(y= probePos ,fill=Gravity),geom='point',alpha=.75) +
  stat_summary(fun.data='mean_se',aes(y=probePos),geom='line', linetype = "dashed", alpha=.75) + 
  #stat_summary(fun.data='mean_se',aes(y=probePos),geom='point',alpha=.9, aes(fill=Gravity)) +
  stat_summary(fun.data='mean_se',geom='line',alpha=.9, size = 1) +
  coord_equal()+
  xlab("Postion in Z") + 
  ylab(" Judgment in Z")+
  ggtitle("IC model, biased Vz")+
  theme_minimal() 
ggarrange(ic, MLE)



## IC 2 Model z_hat = sqrt((ze/z)-1) *gr +1) *z
ggarrange(MLE, ssm)


##############NEW IC#####


ModelData$speed_2 <- 0.37 + 1.76*ModelData$speed -0.03*ModelData$speed^2

ModelData$E_pred  <- ModelData$speed_2/11.76 *sqrt((2*h)/(9.81* (10^-3))) 
ModelData$Gravity <- as.factor(ModelData$Gravity)

ggplot(data=ModelData,aes(x=as.numeric(as.character(ballPos_z)),y=E_pred, color = Gravity, group = Gravity)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',geom='point',alpha=.9) +
  stat_summary(fun.data='mean_se',geom='line',alpha=.9) +
  coord_equal()+   theme_minimal() + xlab("Postion in Z") + 
  ylab(" Zp IC model ")



##############SSM#######

Bm = function(guess,ballPos_z,E_pred, w_s, data){
  # Parameters
  W_e = guess[1] # we are fitting the reliability of the prediction
  w_s <-1.03388
  Z_s = ballPos_z
  Z_e = E_pred
  
  # Model Equation
  #alpha_hat = sqrt(R_n*((kz^2 * Rg)-1) +1)*alpha_i
  #alpha_hat = sqrt(R_n*(Rg-1) +1)*alpha_i
  #alpha_hat = sqrt(R_n*(Rg) +1)*alpha_i
  Z_hat = sqrt((W_e*Z_e)^2 + (w_s*Z_s)^2)
  simulation_error = sqrt(mean((Z_hat-data)^2,na.rm=T)) #RMSE
  return (simulation_error)
}
# Setup for the optimizer

vec = NULL
guess = c(runif(1, 1, 300)) # initial guess for the fit parameter
LB =  c(0.0)
UB =  c(1000.0)
opt_print=0
options = list('algorithm'='NLOPT_LN_COBYLA',#'NLOPT_LN_BOBYQA',#'NLOPT_LN_NELDERMEAD',#'NLOPT_LN_SBPLX',
               'print_level'=opt_print,
               'maxtime'=240) # better not take this long

# Do the Optimization
outdata_ic2=NULL
fitParams_bySubj = NULL
for (sb in unique(ModelData$subjName)){
  tempfit = subset(ModelData, subjName==sb)
  soln = nloptr(x0 = guess,
                eval_f = Bm,
                lb = LB,
                ub = UB,
                opts=options,
                ballPos_z = as.numeric(as.character(tempfit$ballPos_z)),
                E_pred = tempfit$E_pred,
                w_s = w_s,
                data = tempfit$probePos)
  
  tempfit$newtonianPrecision=soln$solution
  
  fitParams_bySubj=c(fitParams_bySubj,soln$solution)
  
  outdata_ic2= rbind(outdata_ic2, tempfit) 
}


outdata_ic2$model_fit =sqrt((outdata_ic2$newtonianPrecision* outdata_ic2$E_pred)^2 + (outdata_ic2$ballPos_z)^2)
outdata_ic2$Gravity <- as.factor(outdata_ic2$Gravity)




ic <- ggplot(data=outdata_ic2,aes(x=as.numeric(as.character(ballPos_z)),y=probePos, color = Gravity, group = Gravity)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',aes(y=model_fit,fill=Gravity),geom='point',alpha=.3) +
  stat_summary(fun.data='mean_se',aes(y=model_fit),geom='line', linetype = "dashed") + 
  stat_summary(fun.data='mean_se',geom='point',alpha=.9, aes(fill=Gravity)) +
  stat_summary(fun.data='mean_se',geom='line',alpha=.9) +
  coord_equal()+
  xlab("Postion in Z") + 
  ylab(" Judgment in Z")+
  ggtitle("IC model, 9/20")+
  theme_minimal() 

#Correct
ggplot(data=outdata_ic2,aes(x=as.numeric(as.character(ballPos_z)),y=model_fit, color = Gravity)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',aes(y= probePos ,fill=Gravity),geom='point',alpha=.75) +
  stat_summary(fun.data='mean_se',aes(y=probePos),geom='line', linetype = "dashed", alpha=.75) + 
  #stat_summary(fun.data='mean_se',aes(y=probePos),geom='point',alpha=.9, aes(fill=Gravity)) +
  stat_summary(fun.data='mean_se',geom='line',alpha=.9, size = 1) +
  coord_equal()+
  xlab("Postion in Z") + 
  ylab(" Judgment in Z")+
  ggtitle("IC model, biased Vz")+
  theme_minimal() 
