
library(gtools)
library(quickpsy)
library(plotrix)
library(ez)
library(stats)

library(plyr)
library(sciplot) # se function
library(tidyverse)
library(broom)
library(olsrr)


rm(list=ls())
data = NULL
trialFiles = NULL
varset = NULL
varset2 = NULL
loll2 = NULL
loll3= NULL

############Mercury#######
dir = paste("~/Documents/Gravity/MainExp1/3.7")
setwd(dir)
filelist = list.files(pattern = ".*.txt")
  
trialFiles_3.7 =  lapply(filelist, function(x)read.table(x, header=T, row.names = NULL)) 
data_3.7 = do.call("rbind", trialFiles_3.7) 
lol_3.7 = subset(data_3.7, select=c('subjName','Gravity', 'alpha','speed', 'trialN','probePos', 'ballPos_y', 'ballPos_z'))
lol_3.7$probePos = lol_3.7$probePos + 600
lol_3.7$ballPos_z = lol_3.7$ballPos_z +600

lol_3.7$subjName <- str_remove(lol_3.7$subjName, '-3.7')

loll_3.7 = with(lol_3.7,aggregate(probePos, 
                            by=list(subjName = subjName,
                                    Gravity=Gravity,
                                    alpha = alpha,
                                    speed = speed,
                                    ballPos_z = ballPos_z,
                                    ballPos_y = ballPos_y 
                                                        ), mean))
names(loll_3.7)[7] = 'probePos'

avData_3.7 =with(loll_3.7,aggregate(probePos,
                           by=list(Gravity=Gravity,
                                   alpha = alpha,
                                   speed = speed,
                                   ballPos_z =ballPos_z
                                  ), mean))

names(avData_3.7)[5] = "probePos"


se.Data_3.7  <- with(lol_3.7,aggregate(probePos, 
                                       by=list(Gravity=Gravity,
                                               alpha = alpha,
                                               speed = speed,
                                               ballPos_z = ballPos_z
                                       ), se))
avData_3.7$se = se.Data_3.7$x

sd.3.7 <- with(lol_3.7,aggregate(probePos, 
                                 by=list(Gravity=Gravity,
                                         alpha = alpha,
                                         speed = speed,
                                         ballPos_z = ballPos_z
                                 ), sd))

avData_3.7$sd = sd.3.7$x






###########################################Earth##########
dir = paste("~/Documents/Gravity/MainExp1/9.81")
setwd(dir)
filelist = list.files(pattern = ".*.txt")

trialFiles_9.81 =  lapply(filelist, function(x)read.table(x, header=T, row.names = NULL)) 
data_9.81 = do.call("rbind", trialFiles_9.81) 
lol_9.81 = subset(data_9.81, select=c('subjName','Gravity', 'alpha','speed', 'trialN','probePos', 'ballPos_y', 'ballPos_z'))
lol_9.81$probePos = lol_9.81$probePos + 600
lol_9.81$ballPos_z = lol_9.81$ballPos_z +600
lol_9.81$speed<- mapvalues(lol_9.81$speed, from = c(5, 6.5), to = c(5.20,6.80))

lol_9.81 <- lol_9.81[order(lol_9.81$ballPos_z),]
lol_3.7 <- lol_3.7[order(lol_3.7$ballPos_z),]
lol_9.81$ballPos_z <- lol_3.7$ballPos_z

lol_9.81$subjName <- str_remove(lol_9.81$subjName, '-9.81')


loll_9.81 = with(lol_9.81,aggregate(probePos, 
                                  by=list(subjName = subjName,
                                          Gravity=Gravity,
                                          alpha = alpha,
                                          speed = speed,
                                          ballPos_z = ballPos_z,
                                          ballPos_y = ballPos_y 
                                  ), mean))
names(loll_9.81)[7] = 'probePos'

avData_9.81 =with(loll_9.81,aggregate(probePos,
                                    by=list(Gravity=Gravity,
                                            alpha = alpha,
                                            speed = speed,
                                            ballPos_z =ballPos_z
                                    ), mean))

names(avData_9.81)[5] = "probePos"
se.Data_9.81 =with(loll_9.81,aggregate(probePos,
                                     by=list(Gravity=Gravity,
                                             alpha = alpha,
                                             speed = speed,
                                             ballPos_z =ballPos_z
                                     ), se))
avData_9.81$se = se.Data_9.81$x

sd.9.81 <- with(lol_9.81,aggregate(probePos, 
                                 by=list(Gravity=Gravity,
                                         alpha = alpha,
                                         speed = speed,
                                         ballPos_z = ballPos_z
                                 ), sd))

avData_9.81$sd = sd.9.81$x

############################################Jupiter########
dir = paste("~/Documents/Gravity/MainExp1/24.79")
setwd(dir)
filelist = list.files(pattern = ".*.txt")

trialFiles_24.79 =  lapply(filelist, function(x)read.table(x, header=T, row.names = NULL)) 
data_24.79 = do.call("rbind", trialFiles_24.79) 
lol_24.79 = subset(data_24.79, select=c('subjName','Gravity', 'alpha','speed', 'trialN','probePos', 'ballPos_y', 'ballPos_z'))
lol_24.79$probePos = lol_24.79$probePos + 600
lol_24.79$ballPos_z = lol_24.79$ballPos_z +600

lol_24.79 <- lol_24.79[order(lol_24.79$ballPos_z),]
lol_24.79$ballPos_z <- lol_3.7$ballPos_z

lol_24.79$subjName <- str_remove(lol_24.79$subjName, '-24.79')
lol_24.79$subjName <- str_remove(lol_24.79$subjName, '_24.79')

loll_24.79 = with(lol_24.79,aggregate(probePos, 
                                    by=list(subjName = subjName,
                                            Gravity=Gravity,
                                            alpha = alpha,
                                            speed = speed,
                                            ballPos_z = ballPos_z,
                                            ballPos_y = ballPos_y 
                                    ), mean))
names(loll_24.79)[7] = 'probePos'

avData_24.79 =with(loll_24.79,aggregate(probePos,
                                      by=list(Gravity=Gravity,
                                              alpha = alpha,
                                              speed = speed,
                                              ballPos_z =ballPos_z
                                      ), mean))

names(avData_24.79)[5] = "probePos"
se.Data_24.79 =with(loll_24.79,aggregate(probePos,
                                       by=list(Gravity=Gravity,
                                               alpha = alpha,
                                               speed = speed,
                                               ballPos_z =ballPos_z
                                       ), se))
avData_24.79$se = se.Data_24.79$x

sd.24.79 <- with(lol_24.79,aggregate(probePos, 
                                   by=list(Gravity=Gravity,
                                           alpha = alpha,
                                           speed = speed,
                                           ballPos_z = ballPos_z
                                   ), sd))

avData_24.79$sd = sd.24.79$x

#####Models#####

avData.simple.1 = with(avData.Total,aggregate(probePos, 
                                             by=list(Gravity=Gravity,
                                                     speed = speed,
                                                     ballPos_z = ballPos_z
                                             ), mean))
avData.simple.2 = with(avData.Total,aggregate(se, 
                                              by=list(Gravity=Gravity,
                                                      speed = speed,
                                                      ballPos_z = ballPos_z
                                              ), mean))
avData.simple.3 = with(avData.Total,aggregate(sd, 
                                              by=list(Gravity=Gravity,
                                                      speed = speed,
                                                      ballPos_z = ballPos_z
                                              ), mean))
avData.simple <- avData.simple.1
names(avData.simple)[4] <- 'probePos'
avData.simple$se <- avData.simple.2$x
avData.simple$sd <- avData.simple.3$x

allData <- rbind(lol_3.7, lol_9.81, lol_24.79)


avData.Total <-rbind(avData_3.7, avData_9.81, avData_24.79)
avData.Total$Gravity[avData.Total$Gravity > 10] <-24.79

sd.data <- subset(sd.3.7, select=c(ballPos_z, x, Gravity))

sd.data <- rbind(sd.data, subset(sd.9.81, select=c(ballPos_z, x, Gravity)))
sd.data <- rbind(sd.data, subset(sd.24.79, select=c(ballPos_z, x, Gravity)))
names(sd.data)[2] <- 'sd'
save('sd.data', file = "sd.data")




save('avData.Total',file='MainData')
save('data.total',file='MainData2')


model.av.em <- rbind(avData_9.81,avData_3.7)

model.av.ej <- rbind(avData_9.81,avData_24.79 )

model.av.mj <- rbind(avData_3.7,avData_24.79 )

data.total <- rbind(lol_3.7, lol_9.81, lol_24.79)

fit1 <-lm(probePos ~ alpha, data=avData.Total)
fit2 <-lm(probePos ~ Gravity, data=avData.Total)
fit3 <-lm(probePos ~ speed, data=avData.Total)
fit4 <-lm(probePos ~ ballPos_z, data=avData.Total)



mfit.em <-lm(probePos ~ alpha + Gravity +speed + Gravity*alpha  + ballPos_z + ballPos_z*Gravity +ballPos_z*speed +ballPos_z*alpha , data=model.av.em)
mfit.ej <-lm(probePos ~ alpha + Gravity +speed + Gravity*alpha  + ballPos_z + ballPos_z*Gravity +ballPos_z*speed +ballPos_z*alpha , data=model.av.ej)
mfit.mj <-lm(probePos ~ alpha + Gravity +speed + Gravity*alpha  + ballPos_z + ballPos_z*Gravity +ballPos_z*speed +ballPos_z*alpha  , data=model.av.mj)
summary(mfit.em)
summary(mfit.ej)
summary(mfit.mj)

mfit2 <-lm(probePos ~ Gravity +speed + Gravity*speed, data=avData.Total)
mfitVel <- lm(probePos ~ Gravity*speed, data=avData.velocity)
tidy(mfitVel)
mfit.non.av <- lm(probePos ~ alpha + Gravity +speed, data=data.total)

mfit <-lm(probePos ~ alpha + Gravity +speed + Gravity*alpha  + ballPos_z + ballPos_z*Gravity +ballPos_z*speed +ballPos_z*alpha , data=avData.Total)
summary(mfit)


mmps(mfit)
mmps(mfit2)
ols_plot_dffits(mfit)
glance(mfit)
glance(mfit2)
glance(mfitVel)
ols_plot_obs_fit(mfit)
ols_plot_obs_fit(mfitVel)

anova(mfit2, mfit)
allData$Gravity <-as.factor(allData$Gravity)
allData$subjName <-as.factor(allData$subjName)
allData$ballPos_z <-as.factor(allData$ballPos_z)
aov = ezANOVA(data = allData, dv = probePos, wid = subjName, within = .(Gravity,ballPos_z))

class(avData.Total$Gravity)
merc.v.earth <-subset(avData.Total, Gravity == 9.81 | Gravity == 3.7 )
merc.v.earth.alpha1 <-subset(merc.v.earth, alpha ==1 )

fit.m.e.alpha1.1 <- lm(probePos~Gravity, data = merc.v.earth.alpha1)
summary(fit.m.e.alpha1.1)
glance1<-glance(fit.m.e.alpha1.1)
plot(fit.m.e.alpha1.1,1)
jup.v.earth <- subset(avData.Total, Gravity >= 9.81 )
jup.v.earth.alpha1 <-subset(jup.v.earth, alpha ==1 )


fit.jup.v.earth.alpha1 <- lm(probePos~Gravity, data = jup.v.earth.alpha1)
summary(fit.m.e.alpha1.1)
glance2<- glance(fit.jup.v.earth.alpha1)

kable(bind_rows(glance1, glance2))
t.test(allData$probePos[allData$Gravity == 9.81],allData$probePos[allData$Gravity == 3.7], alternative = "greater")
t.test(allData$probePos[allData$Gravity == 9.81],allData$probePos[allData$Gravity == 24.790001], alternative = "less")
plot(fit.m.e.alpha1.1,1)

####################variance###################################

varset = with(lol,aggregate(probePos,
                             by = list(subjName = subjName,
                                     Gravity=Gravity,
                                     alpha = alpha,
                                     speed = speed,
                                     ballPos_z =ballPos_z,
                                     ballPos_y = ballPos_y
                                     
                             ),sd))
names(varset)[7] = 'variance'

#### averages 
varset2 = with(varset,aggregate(variance,
                             by=list(Gravity=Gravity,
                                     alpha = alpha,
                                     speed = speed,
                                     ballPos_z =ballPos_z
                             ), mean))


names(varset2)[5] = 'variance'

varsetse = with(varset,aggregate(variance,
                                by=list(Gravity=Gravity,
                                        alpha = alpha,
                                        speed = speed,
                                        ballPos_z =ballPos_z
                                ), se))

varset2$rel = 1/varset2$variance
varset2$se = varsetse$x



varset3 = varset2 %>%
  filter(speed == '5' | speed== '3.14' | speed == '8.14')


varset4 = varset2 %>%
  filter(speed == '6.5' | speed== '4.08' | speed == '10.58')


#########################by speed############################
ggplot(avData.simple, aes(x=as.numeric(as.character(ballPos_z)), y=as.numeric(as.character(probePos)), group = as.factor(Gravity), color = as.factor(Gravity))) +
  geom_point( )  + geom_errorbar(aes(ymin=probePos-se, ymax=probePos+se), width=.2, position=position_dodge(.1)) + 
  geom_abline(intercept=0,slope=1,lty='longdash',col='gray') +
  coord_cartesian(xlim=c(0,130),ylim=c(0,130))+
  theme_minimal() + xlab("Displayed Position in Z" ) + ylab("Response Position in Z" )+
  scale_color_manual(values = c("springgreen3", "deepskyblue3", "orangered3")) + theme(legend.position="top", legend.text = element_text (size=6.5)) 




ggplot(allData, aes(x=as.numeric(as.character(ballPos_z)), y=as.numeric(probePos), color = as.factor(Gravity), group = as.factor(Gravity))) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=3) +
  xlab("Displayed Position in Z (mm) " ) + ylab("Response in Z (mm)" )+
  theme_minimal()


setwd("~/Documents/Gravity/MainExp2/")
EXP1data = allData
save("EXP1data", file  = "EXP1data" )



#Difference
avData.simple$difference <- abs(avData.simple$ballPos_z - avData.simple$probePos)

ggplot(avData.simple, aes(x=(as.factor(Gravity)), y=difference, fill = as.factor(Gravity))) + 
  geom_bar(stat="identity", position=position_dodge()) + theme_minimal() 
  scale_fill_manual(breaks = c("3.7", "9.81", "24.79"), 
                    values=c("springgreen3", "deepskyblue3", "orangered3"))  

