
library(gtools)
library(quickpsy)
library(plotrix)
library(ez)
library(stats)
library(ggpubr)
library(plyr)
library(sciplot) # se function
library(tidyverse)
library(broom)
library(olsrr)
library(lme4)
library(nloptr)
options(scipen=999)

rm(list=ls())

dir = paste("~/Documents/Gravity/SpeedEstimation/")
setwd(dir)

#####Data File loader#########
filelist= list.files(pattern = ".*.txt")



allData_tails= data.frame()
newdata= data.frame()


for (n in filelist){
  tempy <-  lapply(n, function(x)read.table(x, header=T, row.names = NULL)) 
  rawData_1 <-NULL
  rawData_1 = do.call("rbind", tempy)
  rm(tempy)
  data_1 <- subset(rawData_1, select=c('response', 'subjName', 'ProbePhase','speed','trialN','probeSpeed'))
  data_1$probeSpeed = as.numeric(as.character(data_1$probeSpeed))
  data_1 <- data_1[order(data_1$trialN),]
  
  v1= unique(data_1$speed)
  for (i in v1){
    print(i)
    tempData_1 = data_1[data_1$speed==i,]
    tailData_1 = tail(tempData_1,5)
    templine_1 = tailData_1[1,2:6]
    templine_1$probeSpeed = mean(tailData_1$probeSpeed)
    newdata = rbind(newdata,templine_1)
    allData_tails=rbind(allData_tails,tailData_1) 
  }
}
allData_velocity <- allData_tails

rm(newdata,tailData_1, tempData_1, templine_1, allData_tails, rawData_1, data_1)


model <- lm(probeSpeed ~ poly(speed, 2, raw = TRUE), data = allData_velocity)
model$coefficients
allData_velocity$speed_2 <- 0.37 + 1.76*allData_velocity$speed -0.03*allData_velocity$speed^2
#velocity in depth graph


  
ggplot(allData_velocity, aes(x=as.numeric(as.character(speed)), y=as.numeric(as.character(probeSpeed)))) +
    stat_summary(fun.data='mean_se',geom='point') +
    stat_summary(fun.data='mean_se',geom='line') +
    stat_summary(fun.data='mean_se',geom='errorbar',width=.3) +
     
    stat_summary( fun.data='mean_se',geom='line', linetype = "dashed",color = 'red', aes(y=as.numeric(as.character(0.37 + 1.76*speed -0.03*speed^2)))) +
    geom_abline(intercept=0,slope=1,lty='longdash',col='gray') +  coord_cartesian(xlim=c(0,25),ylim=c(0,25)) +
    theme_minimal() + xlab("Displayed Velocity in Z") + ylab("Response in X" ) 
  










###### EXP 1 data ####
dir <- paste("~/Documents/Gravity/MainExp2/") 
setwd(dir)
load('EXP1data')


h <- 67.83 #mm
EXP1data$ballPos_z[EXP1data$ballPos_z < 35] <- 34.25
EXP1data$ballPos_z[EXP1data$ballPos_z > 35 & EXP1data$ballPos_z < 50  ] <- 44.50
EXP1data$ballPos_z[EXP1data$ballPos_z > 50 & EXP1data$ballPos_z < 60  ] <- 55.00
EXP1data$ballPos_z[EXP1data$ballPos_z > 70 & EXP1data$ballPos_z < 73  ] <- 72.00
EXP1data$ballPos_z[EXP1data$ballPos_z > 73 & EXP1data$ballPos_z < 90  ] <- 89.00
EXP1data$ballPos_z[EXP1data$ballPos_z > 90 & EXP1data$ballPos_z < 120  ] <- 116.50


# Experiment 1 data graph
ggplot(EXP1data, aes(x=ballPos_z , y=probePos, color = as.character(Gravity))) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=3) + xlim(0, 150)+ ylim(0, 150)+ 
  xlab("Displayed Position in Z (mm) " ) + ylab("Response in Z (mm)" )+
  theme_minimal()






##### EXP 2 DATA
dir <- paste("~/Documents/Gravity/Sensory exp 22/") 
setwd(dir)
load('allData_sensory')


varset <- with(allData_sensory,aggregate(probePos,
                                 by=list( ballPos_z=ballPos_z
                                 ), var))
names(varset)[2]="Variance"

#Sensory Exp Graph
ggplot(allData_sensory, aes(x=ballPos_z,y=probePos)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=.5) +
  theme_minimal() 



ModelData <- with(EXP1data,aggregate(probePos,
                                     by=list(subjName = subjName, 
                                             Gravity = Gravity, 
                                             speed = speed, 
                                             ballPos_z=ballPos_z
                                     ), mean))



names(ModelData)[5]="probePos"



#precisions of sesnory data
ModelData$precisions_sensory <- 0
ModelData$precisions_sensory[ModelData$ballPos_z == 34.25] <- mean(1/varset$Variance[varset$ballPos_z == 34.25])
ModelData$precisions_sensory[ModelData$ballPos_z == 44.50] <- mean(1/varset$Variance[varset$ballPos_z == 44.50])
ModelData$precisions_sensory[ModelData$ballPos_z == 55.00] <- mean(1/varset$Variance[varset$ballPos_z == 55.00])
ModelData$precisions_sensory[ModelData$ballPos_z == 72.00] <- mean(1/varset$Variance[varset$ballPos_z == 72.00])
ModelData$precisions_sensory[ModelData$ballPos_z == 89.00] <- mean(1/varset$Variance[varset$ballPos_z == 89.00])
ModelData$precisions_sensory[ModelData$ballPos_z == 116.50] <- mean(1/varset$Variance[varset$ballPos_z == 116.50])



########speed model (model 2):#####
#formula for speed estimation log(vz) = a*log(vz_hat)

# Bm = function(guess,vz, data){
#   # Parameters
#   # Model Equation
#   vz_hat = guess[0] + guess[1]*vz +( guess[2]*(vz)^2)
#   
#   simulation_error = sqrt(mean((vz_hat - data )^2,na.rm=T)) #RMSE
#   
#   
#   return (simulation_error)
# }
# # Setup for the optimizer
# 
# vec = NULL
# guess = c(1,1,1) # initial guess for the fit parameter
# LB =  c(0.0, 0.0, 0.0)
# UB =  c(1000.0, 1000.0, 1000.0)
# opt_print=0
# options = list('algorithm'='NLOPT_LN_BOBYQA',#'NLOPT_LN_BOBYQA',#'NLOPT_LN_NELDERMEAD',#'NLOPT_LN_SBPLX',
#                'print_level'=opt_print,
#                'maxtime'=500) # better not take this long
# 
# # Do the Optimization
# outdata=NULL
# fitParams_bySubj = NULL
# for (sb in unique(allData_velocity$subjName)){
#   tempfit = subset(allData_velocity, subjName==sb)
#   soln = nloptr(x0 = guess,
#                 eval_f = Bm,
#                 lb = LB,
#                 ub = UB,
#                 opts=options,
#                 vz = as.numeric(as.character(tempfit$speed)),
#                 data = tempfit$probeSpeed)
#   tempfit$c=soln$solution[0]
#   tempfit$a=soln$solution[1]
#   tempfit$b=soln$solution[2]
#   #fitParams_bySubj=c(fitParams_bySubj,soln$solution)
#   
#   outdata = rbind(outdata, tempfit) 
# }
# 
# 
# outdata$model_velocity <- outdata$a* (outdata$speed)^2
# 
######



#Formula for Earth prediction: Z_p = vz_hat sqrt(2h/9.81)

x <- model$coefficients #the mean values used for fitting Earth prediction
x<- as.data.frame(x)
model_c <- x[,1]

ModelData$Vz_hat <- (model_c[1] + model_c[2]*ModelData$speed + model_c[3]*ModelData$speed^2)

ModelData$Z_p <- (ModelData$Vz_hat/11) * sqrt((2*h)/ (9.81* (10^-3)))
ModelData$Z_p_nb <- (ModelData$speed/11) * sqrt((2*h)/ (9.81* (10^-3)))

ggplot(ModelData, aes(x=ballPos_z , y=Z_p, color = as.character(Gravity))) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=3) + xlim(0, 150)+ ylim(0, 230)+ 
  xlab("Displayed Position in Z (mm) " ) + ylab("Response in Z (mm)" )+
  coord_equal()+
  theme_minimal()


ggplot(ModelData, aes(x=ballPos_z , y=probePos, color = as.character(Gravity))) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',aes(y=Z_p),geom='point',alpha=.3) +
  stat_summary(fun.data='mean_se',aes(y=Z_p),geom='line',alpha=.3, line = 'dash') +
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=3) + xlim(0, 150)+ ylim(0, 230)+ 
  xlab("Displayed Position in Z (mm) " ) + ylab("Response in Z (mm)" )+
  theme_minimal()


ggplot(ModelData, aes(x=ballPos_z , y=probePos, color = as.character(Gravity))) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',aes(y=Z_p_nb),geom='point',alpha=.3) +
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=3) + xlim(0, 150)+ ylim(0, 150)+ 
  xlab("Displayed Position in Z (mm) " ) + ylab("Response in Z (mm)" )+
  theme_minimal()


ggplot(ModelData, aes(x=ballPos_z , y=Z_p_nb, color = as.character(Gravity))) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=3) + xlim(0, 150)+ ylim(0, 150)+ 
  xlab("Displayed Position in Z (mm) " ) + ylab("Response in Z (mm)" )+
  coord_equal()+
  theme_minimal()


# 
# 
# #bin the speeds
# ModelData$bin_speed <- 0 
# ModelData$bin_speed[ModelData$speed == 2] <- 2
# ModelData$bin_speed[ModelData$speed == 2.60] <- 2
# ModelData$bin_speed[ModelData$speed == 3.14] <- 2
# ModelData$bin_speed[ModelData$speed == 3.20] <- 2
# ModelData$bin_speed[ModelData$speed == 4.08] <- 5.68
# ModelData$bin_speed[ModelData$speed == 4.20] <- 5.68
# ModelData$bin_speed[ModelData$speed == 5.20] <- 5.68
# ModelData$bin_speed[ModelData$speed == 6.80] <- 5.68
# ModelData$bin_speed[ModelData$speed == 8.14] <- 9.84
# ModelData$bin_speed[ModelData$speed == 8.35] <- 9.84
# ModelData$bin_speed[ModelData$speed == 10.58] <- 9.84
# ModelData$bin_speed[ModelData$speed == 10.86] <- 9.84
# ModelData$bin_speed[ModelData$speed == 13.60] <- 13.76
# ModelData$bin_speed[ModelData$speed == 17.68] <- 17.68
# 
# #add the slopes
# Velocity_slopes$slope
# ModelData$slope <- 0
# ModelData$slope[ModelData$bin_speed == 2] <- 1.876364
# ModelData$slope[ModelData$bin_speed == 5.68] <- 1.641585
# ModelData$slope[ModelData$bin_speed == 9.84] <- 1.465632
# ModelData$slope[ModelData$bin_speed == 13.76] <- 1.34659
# ModelData$slope[ModelData$bin_speed == 17.68] <- 1.203826
# 
# 
# ModelData$E_pred  <- (ModelData$slope* ModelData$speed/11.76) *sqrt((2*h)/(9.81* (10^-3))) 
# 
# 







#outdata$model_fit = outdata$currentInfoWeight*outdata$ballPos_z + (1-outdata$currentInfoWeight)*outdata$E_pred



# ######MLE model##### 
# Bm = function(guess,ballPos_z,Z_p,reliabilities, data){
#   # Parameters
#   R_n = guess[1] # we are fitting the reliability of the prediction
#   R_i = reliabilities
#   alpha_i = ballPos_z
#   alpha_n = Z_p
#   
#   # Model Equation
#   alpha_hat = (R_i/(R_i + R_n ))*alpha_i + (1- (R_i/(R_i + R_n )))*alpha_n
#   
#   simulation_error = sqrt(mean((alpha_hat-data)^2,na.rm=T)) #RMSE
#   
#   return (simulation_error)
# }
# # Setup for the optimizer
# 
# vec = NULL
# guess = c(runif(1, 1, 300)) # initial guess for the fit parameter
# LB =  c(0.0)
# UB =  c(1000.0)
# opt_print=0
# options = list('algorithm'='NLOPT_LN_COBYLA',#'NLOPT_LN_BOBYQA',#'NLOPT_LN_NELDERMEAD',#'NLOPT_LN_SBPLX',
#                'print_level'=opt_print,
#                'maxtime'=240) # better not take this long
# 
# # Do the Optimization
# MLE_data=NULL
# fitParams_bySubj = NULL
# for (sb in unique(ModelData$subjName)){
#   tempfit = subset(ModelData, subjName==sb)
#   soln = nloptr(x0 = guess,
#                 eval_f = Bm,
#                 lb = LB,
#                 ub = UB,
#                 opts=options,
#                 ballPos_z = as.numeric(as.character(tempfit$ballPos_z)),
#                 Z_p = tempfit$Z_p,
#                 reliabilities = tempfit$precisions_sensory,
#                 data = tempfit$probePos)
#   
#   tempfit$newtonianPrecision=soln$solution
#   
#   fitParams_bySubj=c(fitParams_bySubj,soln$solution)
#   
#   MLE_data = rbind(MLE_data, tempfit) 
# }
# 
# MLE_data$ballPos_z = as.numeric(as.character(MLE_data$ballPos_z))
# MLE_data$currentInfoWeight = (MLE_data$precision/(MLE_data$precision + MLE_data$newtonianPrecision))
# 
# 
# 
# MLE_data$model_fit = MLE_data$currentInfoWeight*MLE_data$ballPos_z + (1-MLE_data$currentInfoWeight)*MLE_data$Z_p
# 
# MLE_data2 = as.data.frame.table(with(MLE_data,as.table(by(probePos,list(subjName,ballPos_z,Gravity),mean,na.rm=T))))
# names(MLE_data2) = c('subject','ballPos_z','Gravity','probePos')
# MLE_data2$model_fit = as.vector(with(MLE_data,as.table(by(model_fit,list(subjName,ballPos_z,Gravity),mean,na.rm=T))))
# 
# MLE <- ggplot(data=MLE_data2,aes(x=as.numeric(as.character(ballPos_z)),y=probePos, color = Gravity)) +
#   geom_abline(intercept=0,slope=1,lty='longdash') +
#   stat_summary(fun.data='mean_se',aes(y=model_fit,fill=Gravity),geom='point',alpha=.3) +
#   stat_summary(fun.data='mean_se',aes(y=model_fit),geom='line', linetype = "dashed") + 
#   stat_summary(fun.data='mean_se',geom='errorbar',width=3)+
#   stat_summary(fun.data='mean_se',geom='point',alpha=.9, aes(fill=Gravity)) +
#   stat_summary(fun.data='mean_se',geom='line',alpha=.9) +
#   coord_equal()+
#   xlab("Postion in Z") + 
#   ylab(" Judgment in Z")+
#   ggtitle("MLE Model")+
#   theme_minimal() 
# 
# 
# #exp1 data
# 
# ggplot(data=MLE_data2,aes(x=as.numeric(as.character(ballPos_z)),y=probePos, color = Gravity)) +
#   geom_abline(intercept=0,slope=1,lty='longdash') +
#   stat_summary(fun.data='mean_se',geom='errorbar',width=3)+
#   stat_summary(fun.data='mean_se',geom='point',alpha=.9, aes(fill=Gravity)) +
#   stat_summary(fun.data='mean_se',geom='line',alpha=.9) +
#   coord_equal()+
#   xlab("Displayed Position in Z (mm) " ) + ylab("Response in Z (mm)" )+
#   theme_minimal() 

##############SSM#######

Bm = function(guess,ballPos_z,Z_p, data){
  # Parameters
  W_p = guess[1] # we are fitting the reliability of the prediction

  Z_s = ballPos_z
  Z_p = Z_p
  
  # Model Equation

  Z_hat = sqrt((W_p*Z_p)^2 + (Z_s)^2)
  simulation_error = sqrt(mean((Z_hat-data)^2,na.rm=T)) #RMSE
  return (simulation_error)
}
# Setup for the optimizer

vec = NULL
guess = c(runif(1, 1, 300)) # initial guess for the fit parameter
LB =  c(0.0)
UB =  c(1000.0)
opt_print=0
options = list('algorithm'='NLOPT_LN_COBYLA',#'NLOPT_LN_BOBYQA',#'NLOPT_LN_NELDERMEAD',#'NLOPT_LN_SBPLX',
               'print_level'=opt_print,
               'maxtime'=240) # better not take this long

# Do the Optimization
outdata_ic=NULL
fitParams_bySubj = NULL
for (sb in unique(ModelData$subjName)){
  tempfit = subset(ModelData, subjName==sb)
  soln = nloptr(x0 = guess,
                eval_f = Bm,
                lb = LB,
                ub = UB,
                opts=options,
                ballPos_z = as.numeric(as.character(tempfit$ballPos_z)),
                Z_p = tempfit$Z_p,
                data = tempfit$probePos)
  
  tempfit$newtonianPrecision=soln$solution
  
  fitParams_bySubj=c(fitParams_bySubj,soln$solution)
  
  outdata_ic = rbind(outdata_ic, tempfit) 
}




outdata_ic$model_fit =sqrt( (outdata_ic$newtonianPrecision*outdata_ic$Z_p)^2 + (outdata_ic$ballPos_z)^2)
outdata_ic$Gravity <- as.factor(outdata_ic$Gravity)

ic <- ggplot(data=outdata_ic,aes(x=as.numeric(as.character(ballPos_z)),y=probePos, color = Gravity, group = Gravity)) +
  geom_abline(intercept=0,slope=1,lty='longdash') +
  stat_summary(fun.data='mean_se',aes(y=model_fit,fill=Gravity),geom='point',alpha=.3) +
  stat_summary(fun.data='mean_se',aes(y=model_fit),geom='line', linetype = "dashed") + 
  stat_summary(fun.data='mean_se',geom='errorbar',width=3)+
  stat_summary(fun.data='mean_se',geom='point',alpha=.9, aes(fill=Gravity)) +
  stat_summary(fun.data='mean_se',geom='line',alpha=.9) +
  coord_equal()+
  xlab("Postion in Z") + 
  ylab(" Judgment in Z")+
  ggtitle("IC Model")+
  theme_minimal() 
ggarrange(ic, MLE, respect=TRUE)



test1 <- lm(probePos ~model_fit, data = MLE_data2)
summary(test1)
test2 <- lm(probePos ~model_fit, data = outdata_ic)
summary(test2)


#calculate AIC of each model
AIC(test1, test2, k = 2)


#BIC?

install.packages('BayesFactor')



