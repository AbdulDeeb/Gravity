
library(gtools)
library(quickpsy)
library(plotrix)
library(ez)
library(stats)

library(plyr)
library(sciplot) # se function
library(tidyverse)
library(broom)
library(olsrr)

options(scipen=999)
rm(list=ls())
data = NULL
trialFiles = NULL
varset = NULL
varset2 = NULL
loll2 = NULL
loll3= NULL
dir = paste("~/Documents/Gravity/Reversed Gravity/Exp1/")
setwd(dir)
filelist = list.files(pattern = ".*.txt")
############Mercury#######

filelist_Merc = grep("_3.7", filelist, perl=TRUE, value=TRUE)
trialFiles_3.7 =  lapply(filelist_Merc, function(x)read.table(x, header=T, row.names = NULL)) 
data_3.7 = do.call("rbind", trialFiles_3.7) 
lol_3.7 = subset(data_3.7, select=c('subjName','Gravity','speed', 'trialN','probePos', 'ballPos_y', 'ballPos_z'))
lol_3.7$probePos = lol_3.7$probePos + 600
lol_3.7$ballPos_z = lol_3.7$ballPos_z +600

loll_3.7 = with(lol_3.7,aggregate(probePos, 
                            by=list(subjName = subjName,
                                    Gravity=Gravity,
                                    speed = speed,
                                    ballPos_z = ballPos_z,
                                    ballPos_y = ballPos_y 
                                                        ), mean))
names(loll_3.7)[6] = 'probePos'

avData_3.7 =with(loll_3.7,aggregate(probePos,
                           by=list(Gravity=Gravity,
                                   speed = speed,
                                   ballPos_z =ballPos_z
                                  ), mean))

names(avData_3.7)[4] = "probePos"


se.Data_3.7  <- with(lol_3.7,aggregate(probePos, 
                                       by=list(Gravity=Gravity,
                                               speed = speed,
                                               ballPos_z = ballPos_z
                                       ), se))
avData_3.7$se = se.Data_3.7$x

sd.3.7 <- with(lol_3.7,aggregate(probePos, 
                                 by=list(Gravity=Gravity,
                                         speed = speed,
                                         ballPos_z = ballPos_z
                                 ), sd))

avData_3.7$sd = sd.3.7$x

# ###########################################Earth##########
# filelist_Earth = grep("_9.81", filelist, perl=TRUE, value=TRUE)
# trialFiles_9.81 =  lapply(filelist_Earth, function(x)read.table(x, header=T, row.names = NULL)) 
# data_9.81 = do.call("rbind", trialFiles_9.81) 
# data_9.81$ballPos_z <- as.numeric(data_9.81$ballPos_z)
# data_9.81$ballPos_z <- round(data_9.81$ballPos_z )
# #keep <- c(-545, -514,-566, -489, -528, -556)
# #drop <- setdiff(unique(data_9.81$ballPos_z), keep)
# #data_9.81 <- data_9.81[data_9.81$ballPos_z  != drop,]
# lol_9.81 = subset(data_9.81, select=c('subjName','Gravity','speed', 'trialN','probePos', 'ballPos_y', 'ballPos_z'))
# unique((lol_9.81$ballPos_z))
# lol_9.81$probePos = lol_9.81$probePos + 600
# lol_9.81$ballPos_z = lol_9.81$ballPos_z +600
# 
# 
# 
# 
# lol_9.81<- lol_9.81 %>%
#   mutate_if(is.numeric, round, digits = 2) %>%
#   filter(speed == c(3.14, 4.08, 5.20, 6.80, 8.14, 10.58))
#   
# 
# loll_9.81 = with(lol_9.81,aggregate(probePos, 
#                                   by=list(subjName = subjName,
#                                           Gravity=Gravity,
#                                           speed = speed,
#                                           ballPos_z = ballPos_z,
#                                           ballPos_y = ballPos_y 
#                                   ), mean))
# names(loll_9.81)[6] = 'probePos'
# 
# avData_9.81 =with(loll_9.81,aggregate(probePos,
#                                     by=list(Gravity=Gravity,
#                                             speed = speed,
#                                             ballPos_z =ballPos_z
#                                     ), mean))
# 
# names(avData_9.81)[4] = "probePos"
# 
# 
# se.Data_9.81  <- with(lol_9.81,aggregate(probePos, 
#                                        by=list(Gravity=Gravity,
#                                                speed = speed,
#                                                ballPos_z = ballPos_z
#                                        ), se))
# avData_9.81$se = se.Data_9.81$x
# 
# sd.9.81 <- with(lol_9.81,aggregate(probePos, 
#                                  by=list(Gravity=Gravity,
#                                          speed = speed,
#                                          ballPos_z = ballPos_z
#                                  ), sd))
# 
# avData_9.81$sd = sd.9.81$x
# if (lol_9.81$ballPos_z == 111.25000){
#   print(x)
# }
# 

############################################Jupiter########
filelist_Earth = grep("_24.79", filelist, perl=TRUE, value=TRUE)
trialFiles_24.79 =  lapply(filelist_Earth, function(x)read.table(x, header=T, row.names = NULL)) 
data_24.79 = do.call("rbind", trialFiles_24.79) 

lol_24.79 = subset(data_24.79, select=c('subjName','Gravity','speed', 'trialN','probePos', 'ballPos_y', 'ballPos_z'))
lol_24.79$probePos = lol_24.79$probePos + 600
lol_24.79$ballPos_z = lol_24.79$ballPos_z +600

loll_24.79 = with(lol_24.79,aggregate(probePos, 
                                    by=list(subjName = subjName,
                                            Gravity=Gravity,
                                            speed = speed,
                                            ballPos_z = ballPos_z,
                                            ballPos_y = ballPos_y 
                                    ), mean))
names(loll_24.79)[6] = 'probePos'

avData_24.79 =with(loll_24.79,aggregate(probePos,
                                      by=list(Gravity=Gravity,
                                              speed = speed,
                                              ballPos_z =ballPos_z
                                      ), mean))

names(avData_24.79)[4] = "probePos"


se.Data_24.79  <- with(lol_24.79,aggregate(probePos, 
                                         by=list(Gravity=Gravity,
                                                 speed = speed,
                                                 ballPos_z = ballPos_z
                                         ), se))
avData_24.79$se = se.Data_24.79$x

sd.24.79 <- with(lol_24.79,aggregate(probePos, 
                                   by=list(Gravity=Gravity,
                                           speed = speed,
                                           ballPos_z = ballPos_z
                                   ), sd))

avData_24.79$sd = sd.24.79$x


#######Clean up#####


# data_3.7$ballPos_z <- as.numeric((unique(data_3.7$ballPos_z)))
# data_24.79$ballPos_z <- as.numeric(data_24.79$ballPos_z )
# as.numeric((unique(data_24.79$ballPos_z)))
lol_24.79$ballPos_z <- round(lol_24.79$ballPos_z, digits = 1)
 unique(lol_24.79$ballPos_z)
lol_3.7$ballPos_z <- round(lol_3.7$ballPos_z, digits = 1)
unique(lol_3.7$ballPos_z)

lol_3.7$ballPos_z[lol_3.7$ballPos_z == 44.5] = 45.0
lol_3.7$ballPos_z[lol_3.7$ballPos_z == 71.9] = 71.8
lol_3.7$ballPos_z[lol_3.7$ballPos_z == 89.0] = 90.0
lol_3.7$ballPos_z[lol_3.7$ballPos_z == 34.2] = 34.4
lol_3.7$ballPos_z[lol_3.7$ballPos_z == 116.4] = 116.9
lol_3.7$ballPos_z[lol_3.7$ballPos_z == 54.8] = 55.2
unique(lol_3.7$ballPos_z)


newdata <- rbind(lol_24.79, lol_3.7)
length(unique(newdata$ballPos_z))
#clean up subjnames 

newdata$subjName <- sapply(strsplit(newdata$subjName , split='_', fixed=TRUE), function(x) (x[1]))

length(unique(newdata$subjName))
#####Models#####

avData_9.81$ballPos_z <- avData_3.7$ballPos_z
avData_24.79$ballPos_z <- avData_3.7$ballPos_z
avData.Total <-rbind(avData_3.7, avData_24.79)
avData.Total$Gravity[avData.Total$Gravity > 10] <-24.79

#clean up of by subject data

str( lol_3.7$ballPos_z)
lol_24.79$ballPos_z <- lol_3.7$ballPos_z
bySubj.Total <- rbind(lol_3.7, lol_24.79)
round(data_3.7$ballPos_z, digits = 0)

x <- strsplit(as.character(bySubj.Total$subjName), split='_', fixed=TRUE)
x<-gsub("_.*","",bySubj.Total$subjName)
bySubj.Total$subjName <- x
bySubj.Total$ballPos_z [bySubj.Total$ballPos_z == 111.25000] <- 85.59000


#save('avData.Total',file='MainData')
#save('bySubj.Total', file = 'bySubj.Total')

save('bySubj.Total', file = 'bySubj.Total.group2')

AllData <- rbind(lol)
newdata$subjName <- as.factor(newdata$subjName)
newdata$Gravity <- as.factor(newdata$Gravity)
newdata$ballPos_z <- as.factor(newdata$ballPos_z)
aov = ezANOVA(data = newdata, dv = probePos, wid = subjName, within = .(Gravity,ballPos_z))


#########################Graphs############################
ggplot(avData.Total, aes(x=as.numeric(as.character(ballPos_z)), y=as.numeric(as.character(probePos)), group = as.factor(Gravity), color = as.factor(Gravity))) +
  geom_point( )  + geom_errorbar(aes(ymin=probePos-se, ymax=probePos+se), width=.3, position=position_dodge(.1)) + geom_line()+
  geom_abline(intercept=0,slope=1,lty='longdash',col='gray') +
  coord_cartesian()+
  theme_minimal() + xlab("Displayed Position in Z" ) + ylab("Response Position in Z" )+
  scale_color_manual(values = c( "deepskyblue3", "orangered3")) + theme(legend.position="top", legend.text = element_text (size=6.5)) 
#by subject 
ggplot(bySubj.Total, aes(x=as.numeric(as.character(ballPos_z)), y=as.numeric(as.character(probePos)), group = as.factor(subjName), color = as.factor(subjName))) +
  geom_point( ) +
  geom_abline(intercept=0,slope=1,lty='longdash',col='gray') +
  coord_equal()+ facet_grid(~Gravity)+
  theme_minimal() + xlab("Displayed Position in Z" ) + ylab("Response Position in Z" )+
  theme(legend.position="top", legend.text = element_text (size=6.5)) 

#correct
ggplot(data=newdata,aes(x=as.numeric(ballPos_z),y=(probePos), color = as.factor(Gravity),
                         group  = as.factor(Gravity))) +
  stat_summary(fun.data=mean_se,geom='point') +
  stat_summary(fun.data=mean_se,geom='line') + 
  stat_summary(fun.data=mean_se,geom='errorbar',width=2) +
  geom_abline(intercept=0,slope=1,lty='longdash',col='gray') +
  xlab("Displayed Position in Z" ) + ylab("Response Position in Z" )+
  theme_minimal() 

save('newdata', file = 'newdata')
#Difference
avData.Total$difference <- abs(avData.Total$ballPos_z - avData.Total$probePos)

ggplot(avData.Total, aes(x=(as.factor(Gravity)), y=difference, fill = as.factor(Gravity))) + 
  geom_bar(stat="identity", position=position_dodge()) + theme_minimal() 
  scale_fill_manual(breaks = c("3.7", "9.81", "24.79"), 
                    values=c("springgreen3", "deepskyblue3", "orangered3"))  

